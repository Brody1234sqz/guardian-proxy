"use strict";

const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const sanitizeHtml = require("sanitize-html");
const crypto = require("node:crypto");
const dns = require("node:dns").promises;
const net = require("node:net");
const path = require("node:path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const PASSWORD = process.env.PROXY_PASSWORD || "";
const SECRET = process.env.SESSION_SECRET || "";
const ALLOWED_HOSTS = (process.env.PROXY_ALLOWED_HOSTS || "")
  .split(",").map(x => x.trim().toLowerCase()).filter(Boolean);
const COOKIE_NAME = "guardian_session";
const SESSION_TTL = 8 * 60 * 60;
const MAX_BODY = 2048;
const MAX_RESPONSE_BYTES = 2 * 1024 * 1024;

if (!PASSWORD || PASSWORD.length < 12) {
  console.error("Set PROXY_PASSWORD to a value of at least 12 characters.");
  process.exit(1);
}
if (!SECRET || SECRET.length < 32) {
  console.error("Set SESSION_SECRET to a random value of at least 32 characters.");
  process.exit(1);
}

app.disable("x-powered-by");
app.set("trust proxy", 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'"],
      imgSrc: ["'self'", "data:"],
      frameSrc: ["'self'"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      frameAncestors: ["'none'"]
    }
  },
  crossOriginEmbedderPolicy: false
}));
app.use(express.json({ limit: "10kb" }));

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: "draft-7", legacyHeaders: false });
const fetchLimiter = rateLimit({ windowMs: 60 * 1000, limit: 30, standardHeaders: "draft-7", legacyHeaders: false });

function sign(value) {
  return crypto.createHmac("sha256", SECRET).update(value).digest("hex");
}
function makeSession() {
  const payload = `${Date.now() + SESSION_TTL * 1000}`;
  return `${payload}.${sign(payload)}`;
}
function validSession(token) {
  if (!token || typeof token !== "string") return false;
  const parts = token.split(".");
  if (parts.length !== 2) return false;
  const [expires, signature] = parts;
  if (!/^\d+$/.test(expires) || Number(expires) < Date.now()) return false;
  const expected = sign(expires);
  return signature.length === expected.length &&
    crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected));
}
function requireAuth(req, res, next) {
  if (validSession(req.headers.cookie?.split(";").map(x => x.trim()).find(x => x.startsWith(COOKIE_NAME + "="))?.slice(COOKIE_NAME.length + 1))) return next();
  return res.status(401).json({ error: "Please sign in again." });
}
function sameOrigin(req, res, next) {
  const origin = req.get("origin");
  if (origin && origin !== `${req.protocol}://${req.get("host")}`) {
    return res.status(403).json({ error: "Cross-origin request blocked." });
  }
  next();
}
function isPrivateIPv4(ip) {
  const p = ip.split(".").map(Number);
  if (p.length !== 4 || p.some(n => !Number.isInteger(n) || n < 0 || n > 255)) return true;
  return p[0] === 0 || p[0] === 10 || p[0] === 127 ||
    (p[0] === 169 && p[1] === 254) ||
    (p[0] === 172 && p[1] >= 16 && p[1] <= 31) ||
    (p[0] === 192 && p[1] === 168) ||
    (p[0] >= 224) || (p[0] === 100 && p[1] >= 64 && p[1] <= 127);
}
function isPrivateIPv6(ip) {
  const s = ip.toLowerCase().split("%")[0];
  return s === "::" || s === "::1" || s.startsWith("fc") || s.startsWith("fd") ||
    /^fe[89ab]/.test(s) || s.startsWith("::ffff:") ||
    s.startsWith("2001:db8:");
}
async function validateTarget(raw) {
  let url;
  try { url = new URL(raw); } catch { throw new Error("Enter a valid website URL."); }
  if (url.protocol !== "https:") throw new Error("Only HTTPS websites are allowed.");
  if (url.username || url.password) throw new Error("URLs containing credentials are blocked.");
  if (url.port && url.port !== "443") throw new Error("Only standard HTTPS port 443 is allowed.");
  const host = url.hostname.toLowerCase().replace(/\.$/, "");
  if (!host || host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local")) {
    throw new Error("That destination is not allowed.");
  }
  if (!ALLOWED_HOSTS.some(rule => host === rule || (rule.startsWith("*.") && host.endsWith(rule.slice(1)) && host !== rule.slice(2)))) {
    throw new Error("This domain is not on the server's allowlist. Ask the administrator to add it.");
  }
  const records = net.isIP(host) ? [{ address: host }] : await dns.lookup(host, { all: true, verbatim: true });
  if (!records.length || records.some(r => net.isIP(r.address) === 4 ? isPrivateIPv4(r.address) : isPrivateIPv6(r.address))) {
    throw new Error("The destination resolves to a restricted network address.");
  }
  return url;
}

app.post("/api/login", loginLimiter, sameOrigin, (req, res) => {
  const supplied = String(req.body?.password || "");
  const a = Buffer.from(supplied);
  const b = Buffer.from(PASSWORD);
  const ok = a.length === b.length && crypto.timingSafeEqual(a, b);
  if (!ok) return res.status(401).json({ error: "Incorrect password." });
  res.cookie(COOKIE_NAME, makeSession(), {
    httpOnly: true, secure: process.env.NODE_ENV === "production",
    sameSite: "strict", maxAge: SESSION_TTL * 1000, path: "/"
  });
  res.json({ ok: true });
});
app.post("/api/logout", sameOrigin, (req, res) => {
  res.clearCookie(COOKIE_NAME, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "strict", path: "/" });
  res.json({ ok: true });
});
app.get("/api/status", requireAuth, (req, res) => res.json({ authenticated: true, allowlistConfigured: ALLOWED_HOSTS.length > 0 }));

app.post("/api/fetch", fetchLimiter, sameOrigin, requireAuth, async (req, res) => {
  try {
    if (typeof req.body?.url !== "string" || req.body.url.length > MAX_BODY) {
      return res.status(400).json({ error: "Enter a URL under 2,048 characters." });
    }
    let target = await validateTarget(req.body.url);
    let response;
    for (let hop = 0; hop <= 3; hop++) {
      response = await fetch(target, {
        method: "GET", redirect: "manual",
        headers: { "User-Agent": "GuardianProxy/1.0", "Accept": "text/html,text/plain,application/xhtml+xml" },
        signal: AbortSignal.timeout(12000)
      });
      if (![301, 302, 303, 307, 308].includes(response.status)) break;
      const location = response.headers.get("location");
      if (!location || hop === 3) throw new Error("Too many or invalid redirects.");
      target = await validateTarget(new URL(location, target).toString());
    }
    const type = (response.headers.get("content-type") || "").toLowerCase();
    if (!type.includes("text/html") && !type.includes("text/plain") && !type.includes("application/xhtml+xml")) {
      return res.status(415).json({ error: "For safety, only HTML and plain-text pages are supported." });
    }
    const reader = response.body.getReader();
    const chunks = [];
    let size = 0;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > MAX_RESPONSE_BYTES) {
        await reader.cancel();
        throw new Error("The page is larger than the 2 MB safety limit.");
      }
      chunks.push(Buffer.from(value));
    }
    const raw = Buffer.concat(chunks).toString("utf8");
    const clean = sanitizeHtml(raw, {
      allowedTags: sanitizeHtml.defaults.allowedTags.concat(["img"]),
      allowedAttributes: { a: ["href", "title"], img: ["src", "alt", "width", "height"], "*": ["lang", "dir"] },
      allowedSchemes: ["https", "mailto"],
      disallowedTagsMode: "discard",
      transformTags: { a: sanitizeHtml.simpleTransform("a", { rel: "noopener noreferrer", target: "_blank" }) }
    });
    res.json({ ok: response.ok, status: response.status, finalUrl: target.toString(), html: clean });
  } catch (err) {
    res.status(400).json({ error: err.name === "TimeoutError" ? "The website took too long to respond." : (err.message || "Unable to load that website.") });
  }
});

app.use(express.static(path.join(__dirname, "public"), { extensions: ["html"] }));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, "0.0.0.0", () => console.log(`Guardian Proxy listening on ${PORT}`));
