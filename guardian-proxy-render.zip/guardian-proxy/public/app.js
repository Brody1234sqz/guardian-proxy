const $ = (id) => document.getElementById(id);
const authPanel = $("authPanel");
const workspace = $("workspace");
const loginMessage = $("loginMessage");
const fetchMessage = $("fetchMessage");

async function api(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    credentials: "same-origin"
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}
function showWorkspace(show) {
  authPanel.classList.toggle("hidden", show);
  workspace.classList.toggle("hidden", !show);
}
async function checkSession() {
  try { await api("/api/status"); showWorkspace(true); }
  catch { showWorkspace(false); }
}
$("loginForm").addEventListener("submit", async (event) => {
  event.preventDefault(); loginMessage.textContent = "Checking access…";
  try {
    await api("/api/login", { method: "POST", body: JSON.stringify({ password: $("password").value }) });
    $("password").value = ""; loginMessage.textContent = ""; showWorkspace(true);
  } catch (error) { loginMessage.textContent = error.message; }
});
$("logoutBtn").addEventListener("click", async () => {
  try { await api("/api/logout", { method: "POST", body: "{}" }); } finally { showWorkspace(false); }
});
$("fetchForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = event.submitter;
  button.disabled = true; button.textContent = "Loading…";
  fetchMessage.textContent = "";
  $("resultTitle").textContent = "Fetching page…";
  $("resultBadge").textContent = "LOADING";
  $("emptyState").classList.remove("hidden");
  $("pageFrame").classList.add("hidden");
  try {
    const result = await api("/api/fetch", { method: "POST", body: JSON.stringify({ url: $("url").value.trim() }) });
    $("resultTitle").textContent = new URL(result.finalUrl).hostname;
    $("resultBadge").textContent = `HTTP ${result.status}`;
    $("pageFrame").srcdoc = result.html;
    $("pageFrame").classList.remove("hidden");
    $("emptyState").classList.add("hidden");
  } catch (error) {
    $("resultTitle").textContent = "Could not load destination";
    $("resultBadge").textContent = "BLOCKED";
    fetchMessage.textContent = error.message;
    $("emptyState").querySelector("strong").textContent = error.message;
  } finally {
    button.disabled = false; button.innerHTML = 'Go <span>→</span>';
  }
});
checkSession();
