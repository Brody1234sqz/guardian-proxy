# Guardian Proxy

A password-protected, allowlisted HTTPS page-fetch proxy designed for deployment on Render.

## Important behavior

This is a **controlled page-fetch proxy**, not a universal browser VPN or unrestricted open proxy. It fetches HTML/plain-text pages from administrator-approved domains and displays sanitized output in a sandboxed frame. It does not support arbitrary CONNECT tunnels, downloads, streaming media, or every website's JavaScript-heavy app.

## Deploy on Render

1. Create a GitHub repository named `guardian-proxy`.
2. Upload the contents of this folder to the repository root (not the ZIP file itself).
3. In Render, choose **New + → Blueprint** and connect the repository. Render reads `render.yaml`.
4. In the service's **Environment** settings, set:
   - `PROXY_PASSWORD`: a unique password of at least 12 characters.
   - `PROXY_ALLOWED_HOSTS`: comma-separated domains, such as `example.com,*.example.org`.
   - `SESSION_SECRET`: Render generates this from the Blueprint; do not share it.
5. Deploy. Open the `onrender.com` URL and sign in.

You can also create a Web Service manually with build command `npm install` and start command `npm start`, then add the same environment variables.

## Add your domain

In Render, open the service's **Settings → Custom Domains**, add your domain, and follow the DNS instructions Render displays. Keep HTTPS enabled.

## Security notes

- Keep the service private and share the password only with intended users.
- Use a strict hostname allowlist. Do not use `*` as an allowlist entry.
- Use a long unique password and keep `SESSION_SECRET` private.
- This project uses HTTPS-only destinations, hostname allowlisting, DNS checks, redirect revalidation, private-address blocking, login/fetch rate limits, request timeouts, a 2 MB response cap, HTML sanitization, and a sandboxed output frame.
- A production-grade unrestricted proxy needs a dedicated network egress policy and a hardened outbound HTTP client that pins validated DNS results to the actual socket connection. This project intentionally avoids unrestricted proxying.
- Free hosting may sleep when idle and has provider-specific resource limits. Confirm current Render plan limits before relying on it.
